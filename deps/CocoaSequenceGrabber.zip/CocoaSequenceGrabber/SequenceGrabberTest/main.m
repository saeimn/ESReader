//
//  main.m
//  SequenceGrabberTest
//
//  Created by Tim Omernick on 3/18/05.
//  Copyright Tim Omernick 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
