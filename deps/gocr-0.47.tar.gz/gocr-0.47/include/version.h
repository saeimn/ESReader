#define version_string "0.47"
#define release_string "20090329"
